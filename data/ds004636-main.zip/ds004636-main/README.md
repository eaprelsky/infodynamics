Cognitive tasks, anatomical MRI, and functional MRI data evaluating the construct of self-regulation
Corresponding author: Dr. Patrick Bissett
For details on dataset, please refer to Data Descriptor:
https://www.ncbi.nlm.nih.gov/pmc/articles/PMC10557703/
